import React from 'react'

const Sliide = () => {
  return (
    <div>
slideee


         
    </div>
  )
}

export default Sliide